//package perfecto.web.service;
//
//import java.io.BufferedWriter;
//import java.io.StringWriter;
//import java.io.Writer;
//import java.math.BigDecimal;
//import java.util.List;
//
//import javax.ws.rs.Consumes;
//import javax.ws.rs.DefaultValue;
//import javax.ws.rs.GET;
//import javax.ws.rs.Path;
//import javax.ws.rs.Produces;
//import javax.ws.rs.QueryParam;
//import javax.ws.rs.core.MediaType;
//import javax.ws.rs.core.Response;
//
//import com.hp.hpl.jena.datatypes.RDFDatatype;
//import com.hp.hpl.jena.ontology.OntModelSpec;
//import com.hp.hpl.jena.rdf.model.Model;
//import com.hp.hpl.jena.rdf.model.ModelFactory;
//import com.hp.hpl.jena.rdf.model.Property;
//import com.hp.hpl.jena.rdf.model.Resource;
//import com.hp.hpl.jena.rdf.model.ResourceFactory;
//import com.hp.hpl.jena.vocabulary.OWL;
//import com.hp.hpl.jena.vocabulary.RDF;
//import com.hp.hpl.jena.vocabulary.RDFS;
//
//import perfecto.common.util.Namespace;
//
///**
// * Ontology Metadata Generator (OMG) Tool to automatically generate ontology metadata as RDF/XML code.
// * @author: GYRARD Amelie, Project in collaboration with EMSE <br/>
// * Created: August 2017 <br/>
// * 
// * TO DO: 
// * - not only RDF/XML but should support other formats
// */
//
//@Path("/omg")
//public class OntologyMetadataGeneratorWS {
//	
//	/**
//	 * Web service to automatically generate ontology metadata as RDF/XML code <br/>
//
//	 * 
//	 * E.g., http://localhost:51234/omg/generateOntologyMetadata/?ontologyName=m3%20ont&ontologyComment=fdfdfdfd&urlOntology=dddd&preferredNamespacePrefix=a&preferredNamespaceUri=d&termStatus=c&creatorEmail=a&creatorName=i&versionNumber=1.0&issued=aa&modified=dddd
//	 * <br/><br/>
//	 *
//	 * Created August 2017 :<br/>
//
//	 * @param ontologyName <br/>
//	 * @param ontologyComment <br/>
//	 * @param urlOntology <br/>
//	 * @param preferredNamespacePrefix  <br/>
//	 * @param preferredNamespaceUri  <br/>
//	 * @param termStatus  <br/>
//	 * @param creatorName  <br/>
//	 * @param creatorEmail  <br/>
//	 * @param versionNumber is a string and Java BigDecimal to be transformed as xsd:type decimal <br/>
//	 * @param modified: last modification date of the ontology <br/>
//	 * @param issued: creation data of the ontology <br/>
//	 * @return the RDF/XML code to insert within the ontology <br/><br/>
//	 * 
//	 */
//	//  @FormParam("") FooBarParamsWrapper wrapper
//	//How can I pass complex objects as arguments to a RESTful service?
//	//https://stackoverflow.com/questions/6061292/how-can-i-pass-complex-objects-as-arguments-to-a-restful-service
//	@GET
//	@Path("/generateOntologyMetadata/")
//	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
//	@Produces(MediaType.TEXT_PLAIN)//APPLICATION_XML, TEXT_PLAIN
//	public static Response generateOntologyMetadata(
//			@DefaultValue("m3 ontology") @QueryParam(value = "ontologyName") String ontologyName,
//			@DefaultValue("dictionnary for sensor data") @QueryParam(value = "ontologyComment") String ontologyComment,
//			@DefaultValue("http://") @QueryParam(value = "urlOntology") String urlOntology,
//			@DefaultValue("m3") @QueryParam(value = "preferredNamespacePrefix") String preferredNamespacePrefix,
//			@DefaultValue("http://") @QueryParam(value = "preferredNamespaceUri") String preferredNamespaceUri,
//			@DefaultValue("Work in Progress") @QueryParam(value = "termStatus") String termStatus,
//			@DefaultValue("Amelie Gyrard") @QueryParam(value = "creatorName") String creatorName,
//			@DefaultValue("amelie.gyrard@emse.fr") @QueryParam(value = "creatorEmail") String creatorEmail,
//			@DefaultValue("1.0") @QueryParam(value = "versionNumber") String versionNumber,
//			@DefaultValue("2017-08-03") @QueryParam(value = "modified") String modified,
//			@DefaultValue("2017-08-03") @QueryParam(value = "issued") String issued
//			) {
//		String message = "web service to automatically generate ontology metadata";
//		//BufferedWriter messageWriter = new BufferedWriter("web service to automatically generate ontology metadata");
//		/** @DefaultValue("") is used to avoid any NullPointerException later in case the parameter is not given or with issues **/
//
//		
//		//output = new BufferedWriter(new FileWriter(file));
//		//messageWriter.write(message);
//		
//		//to test
//		//ontologyName = "The Machine-to-Machine Measurement (M3) Ontology";
//		
//		System.out.println("Web service called: /omg/generateOntologyMetadata/");
//		System.out.println("Param ontologyName: "+ ontologyName);
//		System.out.println("Param ontologyComment: "+ ontologyComment);
//		System.out.println("Param urlOntology: "+ urlOntology);
//		
//		Model ontology_metadata_generated = ModelFactory.createDefaultModel();
//		ontology_metadata_generated.setNsPrefix("dc",  Namespace.NS_DC);
//		ontology_metadata_generated.setNsPrefix("vann",  Namespace.NS_VANN);
//		ontology_metadata_generated.setNsPrefix("vs",  Namespace.NS_VS);
//		ontology_metadata_generated.setNsPrefix("foaf",  Namespace.NS_FOAF);
//		ontology_metadata_generated.setNsPrefix("dcterms",  Namespace.NS_DCTERMS);
//		ontology_metadata_generated.setNsPrefix("voaf",  Namespace.NS_VOAF);
//		//Property applicativeDomain = ResourceFactory.createProperty(Var.NS_M3_LITE, "domainOfInterest"); 
//
//		//Ontology ont = m.getOntology( baseURI );
//		//ont.addProperty( DCTerms.creator, "John Smith" );
//		
//		/** create <owl:Ontology rdf:about="&m3;">**/
//		Resource owl_Ontology = ontology_metadata_generated.createResource(OWL.Ontology);
//		//owl_Ontology.addProperty(RDF)
//		
//		/**  create this triple <rdf:type rdf:resource="&voaf;Vocabulary"/> **/
//		Resource vocabulary = ontology_metadata_generated.createResource(Namespace.NS_VOAF + "Vocabulary");
//		owl_Ontology.addProperty(RDF.type, vocabulary);
//		
//		/**  create this triple <dc:title xml:lang="en">The Machine-to-Machine Measurement (M3) Ontology</dc:title> **/
//		Property dc_title = ResourceFactory.createProperty(Namespace.NS_DC + "title"); 
//		owl_Ontology.addProperty(dc_title, ontology_metadata_generated.createLiteral(ontologyName, "en"));
//		
//		/**  create this triple <dc:descriptione xml:lang="en">The Machine-to-Machine Measurement (M3) Ontology</dc:description> **/
//		Property description = ResourceFactory.createProperty(Namespace.NS_DC + "description"); 
//		owl_Ontology.addProperty(description, ontology_metadata_generated.createLiteral(ontologyComment, "en"));
//		
//		/**  create this triple <dcterms:modified rdf:datatype="http://www.w3.org/2001/XMLSchema#date">2017-08-03</dcterms:modified> **/
//		Property modifiedProperty = ResourceFactory.createProperty(Namespace.NS_DCTERMS + "modified"); 
//		owl_Ontology.addProperty(modifiedProperty, ontology_metadata_generated.createTypedLiteral(modified));
//		
//		/**  create this triple <dcterms:issued rdf:datatype="http://www.w3.org/2001/XMLSchema#date">2013-02-21</dcterms:issued> **/
//		Property issuedProperty = ResourceFactory.createProperty(Namespace.NS_DCTERMS + "issued"); 
//		owl_Ontology.addProperty(issuedProperty, ontology_metadata_generated.createTypedLiteral(issued));
//		
//		/**  create this triple <dc:creator> **/
//		Property creator = ResourceFactory.createProperty(Namespace.NS_DC + "creator"); 
//		owl_Ontology.addProperty(creator, ontology_metadata_generated.createLiteral(creatorName));
//		
//		/**  create this triple <foaf:Person> **/
//		Property emailProperty = ResourceFactory.createProperty(Namespace.NS_FOAF + "Person"); 
//		owl_Ontology.addProperty(emailProperty, ontology_metadata_generated.createTypedLiteral(creatorEmail));
//		
//		/**  create this triple <owl:versionInfo rdf:datatype="http://www.w3.org/2001/XMLSchema#decimal">1.0</owl:versionInfo> **/
//		BigDecimal versionNumberDecimal = new BigDecimal(versionNumber);
//		owl_Ontology.addProperty(OWL.versionInfo, ontology_metadata_generated.createTypedLiteral(versionNumberDecimal));
//		
//		/**  create this triple <rdfs:comment xml:lang="en">fsdfdsfsd</rdfs:comment> **/
//		//usefule for automatic ontology documentation: LODE or Parrot
//		// but duplication with dc:description ok
//		owl_Ontology.addProperty(RDFS.comment, ontology_metadata_generated.createLiteral(ontologyComment, "en"));
//		
//		/** create this triple <vann:preferredNamespacePrefix>m3</vann:preferredNamespacePrefix>  **/
//		Property vann_preferredNamespacePrefix = ResourceFactory.createProperty(Namespace.NS_VANN + "preferredNamespacePrefix"); 
//		owl_Ontology.addProperty(vann_preferredNamespacePrefix, ontology_metadata_generated.createLiteral(preferredNamespacePrefix));
//		
//		/** create this triple  <vann:preferredNamespaceUri>http://sensormeasurement.appspot.com/m3#</vann:preferredNamespaceUri>  **/
//		Property vann_preferredNamespaceUri = ResourceFactory.createProperty(Namespace.NS_VANN + "preferredNamespaceUri"); 
//		owl_Ontology.addProperty(vann_preferredNamespaceUri, ontology_metadata_generated.createLiteral(preferredNamespaceUri)); 
//		
//		/** create this triple <vs:term_status>Work in progress</vs:term_status>  **/
//		Property vs_term_status = ResourceFactory.createProperty(Namespace.NS_VS + "term_status"); 
//		owl_Ontology.addProperty(vs_term_status, ontology_metadata_generated.createLiteral(termStatus));
//		
//			
//		
//		
//		//test
//		
//		//owl_Ontology.createResource(Namespace.NS_VOAF + "Vocabulary");
//		
//		//ontology_metadata_generated.createResource(Namespace.NS_DC + "title");
//		//model.getNsPrefixURI("");
//		
//		//dc_title.addProperty(RDFS.label, ontology_metadata_generated.createLiteral(ontologyName, "en"));
//		//owl_Ontology.addProperty(dc_title);
//		//A testbed is a subclass of ssn:system concept
//		//dc_title.addProperty(RDF.type, ontology_metadata_generated.getResource(Namespace.NS_SSN + "System"));
//
//
//		// Add label and comment
//		
//		//dc_title.addProperty(RDFS.comment, ontology_metadata_generated.createLiteral(ontologyComment, "en"));
//
//		//ontology URL to get access to the ontology
//		//dc_title.addProperty(endpointProperty, ontology_metadata_generated.getResource(urlOntology)); 		
//
//		System.out.println("Ontology metadata automatically generated as RDF/XML. It is compliant with DC, FOAF, etc. ontologies");
//		ontology_metadata_generated.write(System.out);
//
//		//to return RDF/XML code for ontology metadata
//		StringWriter sw = new StringWriter();
//		sw.write(message);
//		ontology_metadata_generated.write(sw, "RDF/XML") ;
//
//		/**
//		
//		"TTL"	TURTLE
//		"Turtle"	TURTLE
//		"N-TRIPLES"	NTRIPLES
//		"N-TRIPLE"	NTRIPLES
//		"NT"	NTRIPLES
//		"JSON-LD"	JSONLD
//		"RDF/XML-ABBREV"	RDFXML
//		"RDF/XML"	RDFXML_PLAIN
//		"N3"	N3
//		"RDF/JSON"	RDFJSON
//		 * "TURTLE"	TURTLE
//		 */
//		//update the ontology metadata generated as RDF/XML
//		return Response.status(200).entity(message).build();
//	}
//	
//	/**
//	 * 	<owl:Ontology rdf:about="&m3;">
//		<rdf:type rdf:resource="&voaf;Vocabulary"/>
//		<dc:title xml:lang="en">The Machine-to-Machine Measurement (M3) Ontology</dc:title>
//		<dc:description xml:lang="en">The Machine-to-Machine Measurement (M3) Ontology is a unified language, nomenclature, dictionnary which enables semantically annotating heterogeneous IoT data produced by heterogeneous devices measurements (sensors, RFID tags, etc.). We classify all devices, their measurements and the feature of interests (health, smart home, smart kitchen, environmental monitoring, etc.). By combining data from heterogeneous areas, we could propose new kinds of applications.</dc:description>
//		<dc:creator>
//  			<foaf:Person rdf:about="mailto:amelie.gyrard@emse.fr">
//   			<foaf:name>Amelie Gyrard</foaf:name>
//  			</foaf:Person>
//		</dc:creator>
//		<dcterms:modified rdf:datatype="http://www.w3.org/2001/XMLSchema#date">2017-07-21</dcterms:modified> 
//		<dcterms:issued rdf:datatype="http://www.w3.org/2001/XMLSchema#date">2013-02-21</dcterms:issued>  		
//		<owl:versionInfo rdf:datatype="http://www.w3.org/2001/XMLSchema#decimal">0.9</owl:versionInfo>
//		<rdfs:comment xml:lang="en">The Machine-to-Machine Measurement (M3) Ontology is a unified language, nomenclature, dictionnary which enables semantically annotating heterogeneous IoT data produced by heterogeneous devices measurements (sensors, RFID tags, etc.). We classify all devices, their measurements and the feature of interests (health, smart home, smart kitchen, environmental monitoring, etc.). By combining data from heterogeneous areas, we could propose new kinds of applications.</rdfs:comment>
//		<vs:term_status>Work in progress</vs:term_status>
//		<vann:preferredNamespacePrefix>m3</vann:preferredNamespacePrefix> 
//	    <vann:preferredNamespaceUri>http://sensormeasurement.appspot.com/m3#</vann:preferredNamespaceUri>
//	</owl:Ontology>
//	 */
//
//}
