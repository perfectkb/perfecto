//
///*********************************************** GENERIC ONE ************************************ /**
//
//
///**  Created: April 2017 /**
//
///** VARIABLES URL WEB SERVICE - VALIDATION TOOLS **/
//var PARROT_URL_WEB_SERVICE = "http://www.ontorule-project.eu/parrot/parrot?documentUri=";
//var WEBVOWL_URL_WEB_SERVICE = "http://vowl.visualdataweb.org/webvowl/#iri=";
//var TRIPLE_CHECKER_URL_WEB_SERVICE = "http://graphite.ecs.soton.ac.uk/checker/?uri=";
//var OOPS_URL_WEB_SERVICE = "http://oops.linkeddata.es/response.jsp?uri=";
//
//var SEAS_ONTOLOGIES_URL = "https://w3id.org/seas/";
//
//function validateOntologiesWithTools_SEASOntology(){
//	provideVisualizationWebVOWL_SEASOntology(document.getElementById('ontologybiggerDropDownList'), document.getElementById('ontology_webvowl_table'));
//	provideDocumentationWithParrot_SEASOntology(document.getElementById('ontologybiggerDropDownList'), document.getElementById('ontology_parrot_table'));
//	loadOntologyTripleChecker_SEASOntology(document.getElementById('ontologybiggerDropDownList'), document.getElementById('ontology_tripleChecker_table'));
//	loadOntologyOops_SEASOntology(document.getElementById('ontologybiggerDropDownList'), document.getElementById('ontology_oops_table'));
//}
//
///** Load ontology with the ontology visaulization Web VOWL tool **/
//function provideVisualizationWebVOWL_SEASOntology(ontology_selected, resultToDisplayTable){
//	//hard coded here does not work if we give it as a parameter, why?
//	var ontology_selected_url = SEAS_ONTOLOGIES_URL;
//	
//	resetElement(resultToDisplayTable);//vider la liste existante
//
////	add a clickable link for visualiwation of ok
//	var a = document.createElement('a');
//	var linkText = document.createTextNode("Loading the ontology selected with WebOWL");
//	a.appendChild(linkText);
//	a.title = ontology_selected_url;
//	a.href = WEBVOWL_URL_WEB_SERVICE + ontology_selected_url;
//	document.body.appendChild(a);
//
//	row = resultToDisplayTable.insertRow(0);
//	var cell11 = row.insertCell(0);
//	cell11.appendChild(a);// data endpoint URL link
//}
//
//
///** Load an ontology and generate the documentation with the Parrot tool **/
//function provideDocumentationWithParrot_SEASOntology(ontology_selected, resultToDisplayTable){
//	//hard coded here does not work if we give it as a parameter, why?
//	var ontology_selected_url = SEAS_ONTOLOGIES_URL;
//	
//	resetElement(resultToDisplayTable);//vider la liste existante
//	
////	add a clickable link for visualiwation of ok
//	var a = document.createElement('a');
//	var linkText = document.createTextNode("Loading the ontology selected with Parrot");
//	a.appendChild(linkText);
//	a.title = ontology_selected_url;
//	a.href = PARROT_URL_WEB_SERVICE + ontology_selected_url;
//	document.body.appendChild(a);
//
//	row = resultToDisplayTable.insertRow(0);
//	var cell11 = row.insertCell(0);
//	cell11.appendChild(a);
//}
//
//
//
///** Load ontology with the syntax validation tool called Triple Checker **/
//function loadOntologyTripleChecker_SEASOntology(ontology_selected, resultToDisplayTable){
//	//hard coded here does not work if we give it as a parameter, why?
//	var ontology_selected_url = SEAS_ONTOLOGIES_URL;
//	
//	resetElement(resultToDisplayTable);//vider la liste existante
//	
////	add a clickable link for visualiwation of ok
//	var a = document.createElement('a');
//	var linkText = document.createTextNode("Loading the ontology selected with Triple Checker");
//	a.appendChild(linkText);
//	a.title = ontology_selected_url;
//	a.href = TRIPLE_CHECKER_URL_WEB_SERVICE + ontology_selected_url;
//	document.body.appendChild(a);
//
//	row = resultToDisplayTable.insertRow(0);
//	var cell11 = row.insertCell(0);
//	cell11.appendChild(a);
//}
//
//
///** Load ontology with the ontology validation tool called Oops **/
//function loadOntologyOops_SEASOntology(ontology_selected, resultToDisplayTable){
//	//hard coded here does not work if we give it as a parameter, why?
//	var ontology_selected_url = SEAS_ONTOLOGIES_URL;
//	
//	resetElement(resultToDisplayTable);//vider la liste existante
//	
//	var a = document.createElement('a');
//	var linkText = document.createTextNode("Loading the ontology selected with OOPS");
//	a.appendChild(linkText);
//	a.title = ontology_selected_url;
//	a.href = OOPS_URL_WEB_SERVICE + ontology_selected_url;
//	document.body.appendChild(a);
//
//	row = resultToDisplayTable.insertRow(0);
//	var cell11 = row.insertCell(0);
//	cell11.appendChild(a);
//}
//
//
//
//function displayOntologyTable(oData, nameTable) {
//	var racine = oData.documentElement;
//	var results = racine.getElementsByTagName("results");
//	var result, binding, msg ="", projectLabel="", projectOntology="", ontologyURL="", projectComment="";
//	var table = document.getElementById(nameTable);
//
//	//clean the table
//	//resetTable(nameTable);
//	//nameTable.innerHTML = "";
//	//document.getElementById(nameTable).deleteRow(0);
//	//ifNoResultDisplayMsg(results, nameTable);//si pas de result trouve// resultat rouge
//
//	//create the first row of the table
//	var row = table.insertRow(0);
//	var columnOntologyFromPaper = row.insertCell(0);
//	var cell02 = row.insertCell(1);
//	var columnOntologyName = row.insertCell(2);
//	var columnOntologyURL = row.insertCell(3);
//	columnOntologyFromPaper.innerHTML = "<b>Ontology from the paper:</b>&nbsp;&nbsp;&nbsp;";
//	//cell02.innerHTML = "<b>Ontology URL Type:</b>&nbsp;&nbsp;&nbsp;";
//	columnOntologyName.innerHTML = "<b>Ontology Name:</b>&nbsp;&nbsp;&nbsp;";
//	columnOntologyURL.innerHTML = "<b>Ontology URL:</b>&nbsp;&nbsp;&nbsp;";// data endpoint URL link
//
//	for(i = 0; i < results.length; i++)	{//all results only 1 tour
//
//		result = results[i].getElementsByTagName("result");
//		//IF NO RESULT FOUND
//		if (result.length == 0){
//			table.insertRow(0);// create a new row
//			var cell1 = row.insertCell(0);// create a new cell
//			cell1.innerHTML = "Sorry, No result found!";
//		}
//
//		//parse the XML result returned by the SPARQL query
//		for(j = 0; j < result.length; j++)	{
//			binding = result[j].getElementsByTagName("binding");
//			msg="", projectOntology="", projectLabel = "", ontologyURL = "";
//			for(k = 0; k < binding.length; k++)	{				
//				if ((binding[k].getAttribute("name") == "projectOntology") && binding[k].childNodes[1].firstChild!=null){
//					projectOntology = binding[k].childNodes[1].firstChild.data;
//				}
//				if ((binding[k].getAttribute("name") == "projectLabel") && binding[k].childNodes[1].firstChild!=null){
//					projectLabel = binding[k].childNodes[1].firstChild.data;
//				}
//				if ((binding[k].getAttribute("name") == "ontologyURL") && binding[k].childNodes[1].firstChild!=null){
//					ontologyURL = binding[k].childNodes[1].firstChild.data;
//				}
//				if ((binding[k].getAttribute("name") == "projectComment") && binding[k].childNodes[1].firstChild!=null){
//					projectComment = binding[k].childNodes[1].firstChild.data;
//				}
//			}			
//
//			if(projectLabel!="" && projectOntology!="" && ontologyURL!=""){
//
//				//display the ontologyURL as a HTML link <a href=""> 
//				var a = document.createElement('a');
//				var linkText = document.createTextNode("Ontology URL");
//				a.appendChild(linkText);
//				a.title = "ontologyURL";
//				a.href = ontologyURL;
//				document.body.appendChild(a);
//
//				// create a new row and cells
//				row = table.insertRow(1);
//				var cellProjectComment = row.insertCell(0);
//				var cellProjectOntology = row.insertCell(1);
//				var cellProjectLabel = row.insertCell(2);
//				var cellOntologyURL = row.insertCell(3);
//				cellProjectComment.innerHTML = projectComment  + "&nbsp;&nbsp;&nbsp;";
//				//cellProjectOntology.innerHTML = projectOntology  + "&nbsp;&nbsp;&nbsp;";
//				cellProjectLabel.innerHTML = projectLabel + "&nbsp;&nbsp;&nbsp;";
//				cellOntologyURL.appendChild(a);// data endpoint URL link
//			}
//
//		}
//	}
//}
//
//
//function displayOntologyDropDownList(oData, nameDiv, nameSubDiv) {
//	var racine = oData.documentElement;
//	var results = racine.getElementsByTagName("results");
//	var result, binding, uri, msg ="", comment="", uri="";
//	var ul = document.getElementById(nameDiv), li;
//
//
//
//	resetElement(ul);//vider la liste existante
//	ifNoResultDisplayMsg(results, nameDiv);//si pas de result trouve// resultat rouge
//
//	for(i = 0; i < results.length; i++)	{//all results only 1 tour
//		result = results[i].getElementsByTagName("result");
//		for(j = 0; j < result.length; j++)	{
//			binding = result[j].getElementsByTagName("binding");
//			msg = "", comment ="", uri="";
//			for(k = 0; k < binding.length; k++)	{
//
//				if ((binding[k].getAttribute("name") == "projectComment")
//						&& binding[k].childNodes[1].firstChild!=null){
//					msg = msg  + binding[k].childNodes[1].firstChild.data;
//				}
//				if ((binding[k].getAttribute("name") == "ontologyURL")
//						&& binding[k].childNodes[1].firstChild!=null){
//					uri = uri + binding[k].childNodes[1].firstChild.data ;
//				}
//				if ( binding[k].getAttribute("name") == "projectLabel" && binding[k].childNodes[1].firstChild!=null){
//					comment = comment  + binding[k].childNodes[1].firstChild.data ;
//				}
//
//			}
//			li = document.createElement(nameSubDiv);
//			li.setAttribute('title', comment );
//			li.setAttribute('value', uri);
//			li.appendChild(document.createTextNode(msg + " " +uri));
//			ul.appendChild(li);
//		}
//	}
//}