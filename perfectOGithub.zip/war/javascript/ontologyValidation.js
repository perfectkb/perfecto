/**  Updated: April 2018 /**
/*********************************************** GENERIC ONE ************************************ /**


/**  Created: April 2017 /**

/** VARIABLES URL WEB SERVICE - VALIDATION TOOLS **/
var WEBVOWL_URL_WEB_SERVICE = "http://vowl.visualdataweb.org/webvowl/#iri=";
var TRIPLE_CHECKER_URL_WEB_SERVICE = "http://graphite.ecs.soton.ac.uk/checker/?uri=";
var OOPS_URL_WEB_SERVICE = "http://oops.linkeddata.es/response.jsp?uri=";
var VAPOUR_URL_WEB_SERVICE = "http://linkeddata.uriburner.com:8000/vapour?uri=";
var LODE_URL_WEB_SERVICE = "http://www.essepuntato.it/lode/";
var PARROT_URL_WEB_SERVICE = "http://www.ontorule-project.eu/parrot/parrot?documentUri=";



function generate_automatic_description_validation_tools_tested(ul){
	var ul, li;
	li = document.createElement("li");
	li.appendChild(document.createTextNode("TripleChecker is used for syntax checking and much more"));
	ul.appendChild(li);
	var li2 = document.createElement("li");
	li2.appendChild(document.createTextNode("WebVOWL is used for automatic graph visualization"));
	ul.appendChild(li2);
	var li3 = document.createElement("li");
	li3.appendChild(document.createTextNode("Parrot and LODE are used or automatic documentation"));
	ul.appendChild(li3);
	var li4 = document.createElement("li");
	li4.appendChild(document.createTextNode("Oops is used to improve the design of the ontology"));
	ul.appendChild(li4);
	var li5 = document.createElement("li");
	li5.appendChild(document.createTextNode("Vapour to check deferencing URI and content negociation"));
	ul.appendChild(li5);
}

/** For the GUI to load an ontology from the URL**/
/** For the GUI to load a specific ontology from LOV4IoT **/
function validateOntologiesWithTools(){
	genericFunctionLoadOntologyValidationTool(
			document.getElementById('ontologybiggerDropDownList'), 
			document.getElementById('ontology_webvowl_table'), 
			WEBVOWL_URL_WEB_SERVICE, 
			"Loading the ontology selected with WebOWL for automatic graph visualization"
			);
	
	genericFunctionLoadOntologyValidationTool(
			document.getElementById('ontologybiggerDropDownList'), 
			document.getElementById('ontology_lode_table'),
			LODE_URL_WEB_SERVICE,
			"Loading the ontology selected with LODE for automatic documentation (Choice 1)"
			);
	
	genericFunctionLoadOntologyValidationTool(
			document.getElementById('ontologybiggerDropDownList'), 
			document.getElementById('ontology_tripleChecker_table'),
			TRIPLE_CHECKER_URL_WEB_SERVICE,
			"Loading the ontology selected with Triple Checker for syntax checking and much more"
			);
	genericFunctionLoadOntologyValidationTool(
			document.getElementById('ontologybiggerDropDownList'), 
			document.getElementById('ontology_oops_table'),
			OOPS_URL_WEB_SERVICE,
			"Loading the ontology selected with OOPS to improve the design of the ontology"
			);
	genericFunctionLoadOntologyValidationTool(
			document.getElementById('ontologybiggerDropDownList'), 
			document.getElementById('ontology_vapour_table'),
			VAPOUR_URL_WEB_SERVICE,
			"Loading the ontology selected with Vapour to check deferencing URI and content negociation"
			);	

	genericFunctionLoadOntologyValidationTool(
			document.getElementById('ontologybiggerDropDownList'), 
			document.getElementById('ontology_parrot_table'),
			PARROT_URL_WEB_SERVICE,
			"NOT MAINTAINED ANYMORE? Loading the ontology selected with Parrot for automatic documentation (Choice 2)"
			);
}

/** specific domain with the domain mechanism **/
function getIoTOntologiesSpecificDomain(){
	var domain = document.getElementById('domainList').value;
	index = domain.indexOf("#"); 
	domain = domain.substring(index+1, domain.length);//get the end of the M3 domain URI

	var data = "domain=" + domain ;//+"&format=xml"

	request(displayOntologyDropDownList, "/perfectoOnto/getOntoDomain/?" + data, "ontologybiggerDropDownList", "option");
}

function getIoTOntologiesSpecificDomainTable(){
	var domain = document.getElementById('domainList').value;
	index = domain.indexOf("#"); 
	domain = domain.substring(index+1, domain.length);//get the end of the M3 domain URI

	var data = "domain=" + domain ;//+"&format=xml"

	 //request(displayOntologyTable, "/perfectoOnto/getOnto/", "ontologyTable", "option");	
	request(displayOntologyTable, "/perfectoOnto/getOntoDomain/?" + data, "ontologyTable", "option");
}



/** specific domain with the domain mechanism **/
/**
 * Used to display all domains referenced within LOV4IoT to then display all ontologies for this specific domain
 * Result displayed in a drop-down list
 * @param oData: XML result returned by the web service
 * @param nameDiv: name of select element
 * @param nameSubDiv: will be option
 * @returns
 */
function displayAllDomainLOV4IoT(oData, nameDiv, nameSubDiv) {
	var racine = oData.documentElement;
	var results = racine.getElementsByTagName("results");
	var result, binding, uri, msg ="", comment="", uri="";
	var ul = document.getElementById(nameDiv), li;

	resetElement(ul);//vider la liste existante
	ifNoResultDisplayMsg(results, nameDiv);//si pas de result trouve// resultat rouge

	for(i = 0; i < results.length; i++)	{//all results only 1 tour
		result = results[i].getElementsByTagName("result");
		for(j = 0; j < result.length; j++)	{
			binding = result[j].getElementsByTagName("binding");
			msg = "", comment ="", uri="";
			for(k = 0; k < binding.length; k++)	{

				if ((binding[k].getAttribute("name") == "domainLabel")
						&& binding[k].childNodes[1].firstChild!=null){
					msg = msg  + binding[k].childNodes[1].firstChild.data;
				}
				if ((binding[k].getAttribute("name") == "domainURL")
						&& binding[k].childNodes[1].firstChild!=null){
					uri = uri + binding[k].childNodes[1].firstChild.data ;
				}
				if ( binding[k].getAttribute("name") == "domainComment" && binding[k].childNodes[1].firstChild!=null){
					comment = comment  + binding[k].childNodes[1].firstChild.data ;
				}

			}
			li = document.createElement(nameSubDiv);
			li.setAttribute('title', comment );
			li.setAttribute('value', uri);
			li.appendChild(document.createTextNode(msg));
			ul.appendChild(li);
		}
	}
}

/** specific domain with the domain mechanism **/
/*
* does not work oDatra null
* Created May 2017
* 
* To display all IoT ontologies from a specific domain (previosuly selected) available within the LOV4IoT RDF dataset
* */
function displayIoTOntologiesSpecificDomain(oData, nameDiv, nameSubDiv) {
	alert(oData);
	var racine = oData.documentElement;
	var results = racine.getElementsByTagName("results");
	var result, binding, uri, msg ="", comment="", uri="";
	var ul = document.getElementById(nameDiv), li;
	
	

	resetElement(ul);//vider la liste existante
	ifNoResultDisplayMsg(results, nameDiv);//si pas de result trouve// resultat rouge

	for(i = 0; i < results.length; i++)	{//all results only 1 tour
		result = results[i].getElementsByTagName("result");
		for(j = 0; j < result.length; j++)	{
			binding = result[j].getElementsByTagName("binding");
			msg = "", comment ="", uri="";
			for(k = 0; k < binding.length; k++)	{

				if ((binding[k].getAttribute("name") == "projectLabel")
						&& binding[k].childNodes[1].firstChild!=null){
					msg = msg  + binding[k].childNodes[1].firstChild.data;
				}
				if ((binding[k].getAttribute("name") == "subject")
					&& binding[k].childNodes[1].firstChild!=null){
					uri = uri + binding[k].childNodes[1].firstChild.data ;
				}
				if ( (binding[k].getAttribute("name") == "projectComment") && binding[k].childNodes[1].firstChild!=null){
					comment = comment  + binding[k].childNodes[1].firstChild.data ;
				}
	
			}
			li = document.createElement(nameSubDiv);
			li.setAttribute('title', comment);
			li.setAttribute('value', uri);
			li.appendChild(document.createTextNode(msg));
			ul.appendChild(li);
		}
	}
}

/** specific domain with the domain mechanism **/


function genericFunctionLoadOntologyValidationTool(ontology_selected, resultToDisplayTable, URL_validationTool, message_ValidationTool){
	var ontology_selected_url = ontology_selected.value;
	resetElement(resultToDisplayTable);//vider la liste existante

//	add a clickable link for visualiwation of ok
	var a = document.createElement('a');
	var linkText = document.createTextNode(message_ValidationTool);//"Loading the ontology selected with WebOWL"
	a.appendChild(linkText);
	a.title = ontology_selected_url;
	a.href = URL_validationTool + ontology_selected_url;//WEBVOWL_URL_WEB_SERVICE
	document.body.appendChild(a);

	row = resultToDisplayTable.insertRow(0);
	var cell11 = row.insertCell(0);
	cell11.appendChild(a);// data endpoint URL link
}


function displayOntologyTable(oData, nameTable) {
	var racine = oData.documentElement;
	var results = racine.getElementsByTagName("results");
	var result, binding, msg ="", projectLabel="", projectOntology="", ontologyURL="", projectComment="";
	var table = document.getElementById(nameTable);

	//clean the table
	//resetTable(nameTable);
	//nameTable.innerHTML = "";
	//document.getElementById(nameTable).deleteRow(0);
	//ifNoResultDisplayMsg(results, nameTable);//si pas de result trouve// resultat rouge

	//create the first row of the table
	var row = table.insertRow(0);
	var columnOntologyFromPaper = row.insertCell(0);
	var cell02 = row.insertCell(1);
	var columnOntologyName = row.insertCell(2);
	var columnOntologyURL = row.insertCell(3);
	columnOntologyFromPaper.innerHTML = "<b>Ontology from the paper:</b>&nbsp;&nbsp;&nbsp;";
	//cell02.innerHTML = "<b>Ontology URL Type:</b>&nbsp;&nbsp;&nbsp;";
	columnOntologyName.innerHTML = "<b>Ontology Name:</b>&nbsp;&nbsp;&nbsp;";
	columnOntologyURL.innerHTML = "<b>Ontology URL:</b>&nbsp;&nbsp;&nbsp;";// data endpoint URL link

	for(i = 0; i < results.length; i++)	{//all results only 1 tour

		result = results[i].getElementsByTagName("result");
		//IF NO RESULT FOUND
		if (result.length == 0){
			table.insertRow(0);// create a new row
			var cell1 = row.insertCell(0);// create a new cell
			cell1.innerHTML = "Sorry, No result found!";
		}

		//parse the XML result returned by the SPARQL query
		for(j = 0; j < result.length; j++)	{
			binding = result[j].getElementsByTagName("binding");
			msg="", projectOntology="", projectLabel = "", ontologyURL = "";
			for(k = 0; k < binding.length; k++)	{				
				if ((binding[k].getAttribute("name") == "projectOntology") && binding[k].childNodes[1].firstChild!=null){
					projectOntology = binding[k].childNodes[1].firstChild.data;
				}
				if ((binding[k].getAttribute("name") == "projectLabel") && binding[k].childNodes[1].firstChild!=null){
					projectLabel = binding[k].childNodes[1].firstChild.data;
				}
				if ((binding[k].getAttribute("name") == "ontologyURL") && binding[k].childNodes[1].firstChild!=null){
					ontologyURL = binding[k].childNodes[1].firstChild.data;
				}
				if ((binding[k].getAttribute("name") == "projectComment") && binding[k].childNodes[1].firstChild!=null){
					projectComment = binding[k].childNodes[1].firstChild.data;
				}
			}			

			if(projectLabel!="" && projectOntology!="" && ontologyURL!=""){

				//display the ontologyURL as a HTML link <a href=""> 
				var a = document.createElement('a');
				var linkText = document.createTextNode(ontologyURL);
				a.appendChild(linkText);
				a.title = "ontologyURL";
				a.href = ontologyURL;
				document.body.appendChild(a);

				// create a new row and cells
				row = table.insertRow(1);
				var cellProjectComment = row.insertCell(0);
				var cellProjectOntology = row.insertCell(1);
				var cellProjectLabel = row.insertCell(2);
				var cellOntologyURL = row.insertCell(3);
				cellProjectComment.innerHTML = projectComment  + "&nbsp;&nbsp;&nbsp;";
				//cellProjectOntology.innerHTML = projectOntology  + "&nbsp;&nbsp;&nbsp;";
				cellProjectLabel.innerHTML = projectLabel + "&nbsp;&nbsp;&nbsp;";
				cellOntologyURL.appendChild(a);// data endpoint URL link
			}

		}
	}
}


function displayOntologyDropDownList(oData, nameDiv, nameSubDiv) {
	var racine = oData.documentElement;
	var results = racine.getElementsByTagName("results");
	var result, binding, uri, msg ="", comment="", uri="";
	var ul = document.getElementById(nameDiv), li;



	resetElement(ul);//vider la liste existante
	ifNoResultDisplayMsg(results, nameDiv);//si pas de result trouve// resultat rouge

	for(i = 0; i < results.length; i++)	{//all results only 1 tour
		result = results[i].getElementsByTagName("result");
		for(j = 0; j < result.length; j++)	{
			binding = result[j].getElementsByTagName("binding");
			msg = "", comment ="", uri="";
			for(k = 0; k < binding.length; k++)	{

				if ((binding[k].getAttribute("name") == "projectLabel")
						&& binding[k].childNodes[1].firstChild!=null){
					msg = msg  + binding[k].childNodes[1].firstChild.data;
				}
				if ((binding[k].getAttribute("name") == "ontologyURL")
						&& binding[k].childNodes[1].firstChild!=null){
					uri = uri + binding[k].childNodes[1].firstChild.data ;
				}
				if ( binding[k].getAttribute("name") == "projectComment" && binding[k].childNodes[1].firstChild!=null){
					comment = comment  + binding[k].childNodes[1].firstChild.data ;
				}

			}
			li = document.createElement(nameSubDiv);
			li.setAttribute('title', comment + "URL:  " + uri );
			li.setAttribute('value', uri);
			li.appendChild(document.createTextNode(msg + " - " + comment));
			ul.appendChild(li);
		}
	}
}