


function createTableAvailabilityTools(idTable){
/*var div = document.createElement('div');
div.setAttribute("id", idTable);
document.body.appendChild(div)*/
	document.getElementById(idTable).innerHTML = "<table border = '1'>" +
  '<tr>' +
    '<th>Name Tool and Logo</th>' +
    '<th>Tool Classification</th> ' +
    '<th>Tool Description</th>' +
    '<th>Integration with this tool</th>' +
    '<th>Tool availability status</th>' +
  '</tr>' +
  '<tr>' +
    '<td>WebVowl</td>' +
    '<td>Visualization</td>' +
    '<td>cell</td>' +
    '<td>cell</td>' +
    '<td>cell</td>' +
  '</tr>' +
  '<tr>' +
    '<td>TripleChecker</td>' +
    '<td>Syntax</td>' +
    '<td>cell</td>' +
    '<td>cell</td>' +
    '<td>cell</td>' +
  '</tr>' +
  '<tr>' +
  '<td>LODE</td>' +
  '<td>Documentation</td>' +
  '<td>cell</td>' +
  '<td>cell</td>' +
  '<td>cell</td>' +
'</tr>' +
  '<tr>' +
  '<td>Parrot</td>' +
  '<td>Documentation</td>' +
  '<td>cell</td>' +
  '<td>cell</td>' +
  '<td>cell</td>' +
'</tr>' +
  '<tr>' +
    '<td>Vapour</td>' +
    '<td>Content Negociation</td>' +
    '<td>cell</td>' +
    '<td>cell</td>' +
    '<td>cell</td>' +
  '</tr>'+
  '<tr>' +
  '<td>Oops</td>' +
  '<td>Ontology Design</td>' +
  '<td>cell</td>' +
  '<td>cell</td>' +
  '<td>cell</td>' +
'</tr>'+
    '<tr>' +
    '<td>LOV</td>' +
    '<td>Dissemination <br/>Ontology Catalog</td>' +
    '<td>cell</td>' +
    '<td>cell</td>' +
    '<td>cell</td>' +
  '</tr>'+
   '<tr>' +
    '<td>LogMap</td>' +
    '<td>Ontology Matching</td>' +
    '<td>cell</td>' +
    '<td>cell</td>' +
    '<td>cell</td>' +
  '</tr>'
};


//add image tool
//pb if no image
var list_status_tools_best_practice = [
{ name_tool: 'OWL Manchester Validator Hosted on Visual Data Web Project for Syntax Validation', 
  url_tool: 'http://visualdataweb.de/validator/',
},

{ name_tool: 'Oops for Designing a better Ontology', 
	url_tool: 'http://oops.linkeddata.es/', // 502 Proxy Error	The proxy server received an invalid response from an upstream server.	The proxy server could not handle the request GET /.	Reason: Error reading from remote server
},


{ name_tool: 'Parrot for Automatic Ontology Documentation', 
	url_tool: 'http://ontorule-project.eu/parrot/parrot', 
},

{ name_tool: 'LODE for Automatic Ontology Documentation', 
	url_tool: 'http://www.essepuntato.it/lode', 
},

{ 
  name_tool: 'Vapour for checking deferenceable URIs', 
  url_tool: 'http://linkeddata.uriburner.com:8000/vapour', //ERR_CONNECTION_TIMED_OUT
},	

{ name_tool: 'TripleChecker for Syntax Validation', 
	url_tool: 'http://graphite.ecs.soton.ac.uk/checker/', 
},

{ name_tool: 'Prefic cc', 
url_tool: 'http://prefix.cc/', 
},
		
{ name_tool: 'RDF Validator for Syntax Validation', 
	url_tool: 'http://www.w3.org/RDF/Validator/', 
	},

{ name_tool: 'OWL Manchester Validator for Syntax Validation', 
	url_tool: 'http://mowl-power.cs.man.ac.uk:8080/validator/', //ERR_CONNECTION_TIMED_OUT
	},
	
{ name_tool: 'SPARQL endpoint status', 
  url_tool: 'http://sparqles.ai.wu.ac.at/', 
},

{ name_tool: 'SPORTAL', 
	  url_tool: 'http://www.sportalproject.org/index.html', 
	},
	
	
{ name_tool: 'FIESTA-IoT Ontology Validator (Requires Login/Password)', 
		  url_tool: ' http://certificate.fiesta-iot.eu', 
		},
	//ERR_CONNECTION_TIMED_OUT
		// http://vps332716.ovh.net/
		//http://185.52.32.74:8080/ontologyValidatorUI/

{ name_tool: 'SSN ontology validation', 
 url_tool: 'http://iot.ee.surrey.ac.uk/SSNValidation/', 
},	

{ name_tool: 'Loupe', 
	 url_tool: 'http://loupe.linkeddata.es/loupe/', 
	},	
	
	// should be error, time response too long nothing happened

{ name_tool: 'WebVOWL web service for automatic graph visualization - example with foaf ontology', 
			 url_tool: 'http://visualdataweb.de/webvowl/#iri=http://xmlns.com/foaf/0.1/', 
},	
	

];
/************************** END CKECK STATUS TOOL *************************/

function displayStatusTool(idStatusTools){
	//private static final String URL_OWL_MANCHESTER_FREQUENTLY_DOWN = "http://mowl-power.cs.man.ac.uk:8080/validator/";

	//private static final String URL_OWL_MANCHESTER_HOSTED_BY_VOWL_WORK_BETTER = "http://visualdataweb.de/validator/";
	
	
//	var URL_OWL_MANCHESTER_HOSTED_BY_VOWL_WORK_BETTER = "http://visualdataweb.de/validator/";
//	requestText(getResult_WebService_StatusTool, '/perfecto/statusTool/?url=' + URL_OWL_MANCHESTER_HOSTED_BY_VOWL_WORK_BETTER, 'status_owl_manchester_vowl');
//	
//	var URL_OWL_MANCHESTER_FREQUENTLY_DOWN = "http://mowl-power.cs.man.ac.uk:8080/validator/";
//	requestText(getResult_WebService_StatusTool, '/perfecto/statusTool/?url=' + URL_OWL_MANCHESTER_FREQUENTLY_DOWN, 'status_owl_manchester');
	
	
	var name_tool = "", url_tool = "";
	
	for(i = 0; i < list_status_tools_best_practice.length; i++)	{
		
		//var emptyDiv = document.createElement('div');
		var div_result_status_tools = document.getElementById(idStatusTools);//nameDiv
		
		
		//var div_result_status_tools = document.createElement('status_all_tools');//nameDiv
		
		//div_result_status_tools.appendChild(emptyDiv);
		name_tool = list_status_tools_best_practice[i].name_tool;
		url_tool = list_status_tools_best_practice[i].url_tool;
		//requestText(getResult_WebService_StatusTool_v2, '/perfecto/statusTool/?url=' + list_status_tools_best_practice[i].url_tool, 'status_all_tools', name_tool, url_tool);
		
		requestTextSimple(getResult_WebService_StatusTool_v3, '/perfecto/statusTool/?url=' + url_tool, 'status_all_tools', 'nameSubDiv', name_tool, url_tool);
	}
	
	//automaticall add a new div
	//'/perfecto/statusTool/?' + data
}

function requestTextSimple(callback, url, nameDiv, nameSubDiv, name_tool, url_tool) {
	var xhr = getXMLHttpRequest();
	//alert(name_tool + "  " + url_tool);

	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4 && (xhr.status == 200 || xhr.status == 0)) {
			callback(xhr.responseText, nameDiv, nameSubDiv, name_tool, url_tool);
		}
	};
	
	xhr.open("GET", url, true);
	xhr.send(null);
}


/**
 * V2 add clickable URL link
 * V1 working: ping the URL of the tool through the Java web service and display a picture accordingly (ok or not ok)
 */
function getResult_WebService_StatusTool_v3(oData, nameDiv, nameSubDiv, name_tool, url_tool){
	//, 'status_all_tools', name_tool, url_tool
	//try with a table
	// try to add clickebla href link on the tool names
	
	//alert(name_tool);
	if (name_tool != "undefined"){
	//alert(oData + " " +  nameDiv  + " " + nameSubDiv + " " + name_tool + " " + url_tool);
	}
	
	var div_result_status_tools = document.createElement('status_all_tools');
	
	var emptyDiv = document.createElement('div');
	
	var div_status_specific_tool = document.createElement('name_tool');
	
	var img = document.createElement('img');
	img.alt = oData;//if the URL of the tool does not work well, we display ok or pas ok
		if (oData == "OK"){
		//display image ok_status_tool
		img.src = '../images/validation_perfecto/ok_status_tool.png';
	}
	else if (oData == "NOT OK"){
		//display image not_ok_status_tool
		img.src = '../images/validation_perfecto/not_ok_status_tool.png';		
		//img.title= "";//explain the reason
	}

	
	//create a clickable link for the URL of the tool
	var link_tool = document.createElement('a');//create link
	var linkText = document.createTextNode("URL tool");//name_tool
	link_tool.appendChild(linkText);
	link_tool.setAttribute('href', url_tool);//TO DO automatically add the URL
	//link_tool.innerHTML = name_tool ;//set text to be seen//list_status_tools_best_practice.url_tool
	//document.body.appendChild(link_tool);//add to body
	
	//add image to the sub div
	
	div_status_specific_tool.textContent =  name_tool + " : Status -> " + "\n\n\n\n\n";
	div_status_specific_tool.appendChild(link_tool);
	div_status_specific_tool.appendChild(img);
	
	div_status_specific_tool.appendChild(emptyDiv);
	
	//automatically add the result to the html web page
	div_result_status_tools.appendChild(div_status_specific_tool);
	document.body.appendChild(div_result_status_tools);
	
}


/**
 * V2 add clickable URL link
 * V1 working: ping the URL of the tool through the Java web service and display a picture accordingly (ok or not ok)
 */
//function getResult_WebService_StatusTool_v2(oData, nameDiv, nameSubDiv, name_tool, url_tool){
//	//, 'status_all_tools', name_tool, url_tool
//	//try with a table
//	// try to add clickebla href link on the tool names
//	
//	//alert(name_tool);
//	if (name_tool != "undefined"){
//	//alert(oData + " " +  nameDiv  + " " + nameSubDiv + " " + name_tool + " " + url_tool);
//	}
//	
//	var div_result_status_tools = document.createElement('status_all_tools');
//	
//	var emptyDiv = document.createElement('div');
//	
//	var div_status_specific_tool = document.createElement('name_tool');
//	var img = document.createElement('img');
//	img.alt = oData;//if the image cannot be loaded, we display ok or pas ok
//	
//	if (oData == "OK"){
//		//display image
//		//ok_status_tool
//		img.src = '../images/validation_perfecto/ok_status_tool.png';
//
//	}
//	else if (oData == "NOT OK"){
//		//display image
//		//not_ok_status_tool
//		img.src = '../images/validation_perfecto/not_ok_status_tool.png';		
//		//img.title= "";//explain the reason
//		
//	}
//
//	
//	//create a clickabe link for the name of the tool
//	var link_tool = document.createElement('a');//create link
//	link_tool.setAttribute('href', url_tool);//TO DO automatically add the URL
//	link_tool.innerHTML = url_tool;//set text to be seen//list_status_tools_best_practice.url_tool
//	document.body.appendChild(link_tool);//add to body
//	
//	//add image to the sub div
//	div_status_specific_tool.textContent = name_tool + " : Status -> " + "\n\n\n\n\n";
//	div_status_specific_tool.appendChild(link_tool);
//	div_status_specific_tool.appendChild(img);
//	
//	div_status_specific_tool.appendChild(emptyDiv);
//	
//	//automatically add the result to the html web page
//	div_result_status_tools.appendChild(div_status_specific_tool);
//	document.body.appendChild(div_result_status_tools);
//	
//}


/**
 * V1 working: ping the URL of the tool through the Java web service and display a picture accordingly (ok or not ok)
 */
//function getResult_WebService_StatusTool(oData, nameDiv, nameSubDiv, list_status_tools_best_practice){
//		
//	var div_result_status_tools = document.createElement('status_all_tools');
//	var emptyDiv = document.createElement('div');
//	var div_status_specific_tool = document.createElement('nameSubDiv');
//	var img = document.createElement('img');
//	
//	img.alt = oData;//if the image cannot be loaded, we display ok or pas ok
//	
//	if (oData == "OK"){
//		//display image ok_status_tool
//		img.src = '../images/validation_perfecto/ok_status_tool.png';
//	}
//	else if (oData == "NOT OK"){
//		//display image not_ok_status_tool
//		img.src = '../images/validation_perfecto/not_ok_status_tool.png';
//	}
//	
//	//add image to the sub div
//	div_status_specific_tool.textContent = nameSubDiv + ": Status -> " + "\n\n\n\n\n";
//	div_status_specific_tool.appendChild(img);
//	div_status_specific_tool.appendChild(emptyDiv);
//	
//	//automatically add the result to the html web page
//	div_result_status_tools.appendChild(div_status_specific_tool);
//	document.body.appendChild(div_result_status_tools);
//}













//function checkVapourNotDead(){
//	
//	//alert("hello");
//	requestVapour(callback, "http://visualdataweb.de/validator/")
//	//use owl validator mowl-power.cs.man.ac.uk:8080/validator/
//}
//
//
////retrieve XML
//function requestVapour(callback, urlTool) {
//	var xhr = getHTMLHttpRequest();
//
//	xhr.onreadystatechange = function() {
//		if (xhr.readyState == 4 && (xhr.status == 200 || xhr.status == 0)) {
//			alert(urlTool + "- server/tool ok");
//			callback(xhr.responseHTML);
//			
//		}
//		// server down, the tool cannot be used
//		else if (xhr.status == 404 ){
//			alert(urlTool + "- server/tool down");
//			
//			}
//	};
//	xhr.open("GET", file, true);
//	xhr.send(null);
//}


/*******************************************************************************

Creator: Amelie Gyrard

CloudIoT: Visualization of ontologies and later datasets

Created: September 2016
- DONE create a list of ontologies working with web vowl
- DONE when we click on the ontology we update the iframe with vowl and the specific ontology
- DONE javascript change iframe source

//TODO  add pictures for each project in LOV4IoT RDF dataset
//TODO add pictures for each ontology

// 11 December 2016
// FiX BUX URL Changed
// url_onto: 'https://mimove-apps.paris.inria.fr/ontology/fiesta-iot.owl',
// http://purl.org/iot/vocab/m3-lite#
// issue m3_lite changed does not work anymore why

 *******************************************************************************/
//BUG: duplicaiton of ontologies in the drop-down list - why?
//var list_onto_to_visualize = [
//{ name_onto: 'openiot ontology', 
//domain_onto: 'IoT domain', 
//  url_onto: 'http://sensormeasurement.appspot.com/ont/sensor/openIoT.owl',
//  image: '../images/cloudiot/ontologies/openiot.png',
//},
//{ name_onto: 'FIESTA-IoT ontology', 
//	domain_onto: 'IoT domain', 
//url_onto: 'http://ontology.fiesta-iot.eu/ontologyDocs/fiesta-iot.owl',
//image: '../images/cloudiot/ontologies/fiesta.png',
//},
//{ name_onto: 'vital ontology', 
//	domain_onto: 'IoT domain', 
//url_onto: 'http://vital-iot.eu/ontology/ns/ontology.owl',
//image: '../images/cloudiot/ontologies/vital.png',
//},
//	                          
//{ name_onto: 'ssn ontology V2', 
//	domain_onto: 'IoT domain', 
//url_onto: 'https://www.w3.org/ns/ssn/',
//image: '../images/cloudiot/ontologies/w3c_ssn_onto.png',
//},
//
//{ name_onto: 'OneM2M ontology ', 
//	domain_onto: 'IoT/M2M domain', 
//url_onto: 'http://www.w3.org/2002/07/owl',
//image: '../images/cloudiot/ontologies/oneM2M.png',
//},
//
//
//	                              // https://www.w3.org/TR/vocab-ssn/ for documentation
//		                           // for the ontology https://www.w3.org/ns/ssn/
//	                             // { name_onto: 'SSN_V1 ontology', url_onto: 'http://purl.oclc.org/NET/ssnx/ssn#'}, does not work with webvowl
//{ name_onto: 'iot-lite ontology', 
//	domain_onto: 'IoT domain', 
//url_onto: 'http://purl.oclc.org/NET/UNIS/fiware/iot-lite#',
//image: '../images/cloudiot/ontologies/iot-lite.png',},
//{ 
//name_onto: 'spitfire ontology', 
//url_onto: 'http://sensormeasurement.appspot.com/ont/sensor/spitfire.owl',
//domain_onto: 'IoT domain', 
//image: '../images/cloudiot/ontologies/spitfire.png',},
//	                             
//{ name_onto: 'sao ontology', 
//	domain_onto: 'IoT domain', 
//url_onto: 'http://purl.oclc.org/NET/UNIS/sao/sao#',
//image: '../images/cloudiot/ontologies/sao.png',
//},
//{ name_onto: 'm3ontology', 
//	domain_onto: 'IoT domain', 
//url_onto: 'http://sensormeasurement.appspot.com/m3#',
//image: '../images/cloudiot/ontologies/m3.png',
//},
//
//
//
//
//{ name_onto: 'Wongpatikseree Home Activity ontology', 
//	domain_onto: 'Home, Activity domain', 
//url_onto: 'http://sensormeasurement.appspot.com/ont/home/homeActivity',
//image: '../images/domainOnto/activity.png',
//},
//	
//	
//{ name_onto: 'Morignot Transport ontology', 
//	domain_onto: 'Transport domain', 
//url_onto: 'http://philippe.morignot.free.fr/Articles/Perception.owl',
//image: '../images/domainOnto/transport.png',
//},
//
//{ name_onto: 'Staroch Weather ontology', 
//	domain_onto: 'Weather domain', 
//url_onto: 'http://paul.staroch.name/thesis/SmartHomeWeather.owl',
//image: '../images/domainOnto/weather.png',
//},
//{ name_onto: 'DogOnt Home ontology', 
//	domain_onto: 'Home domain', 
//url_onto: 'http://elite.polito.it/ontologies/dogont.owl',
//image: '../images/domainOnto/home.png',
//},
//
//
//
//
//
//{ name_onto: 'Ruta Transport ontology', 
//	domain_onto: 'Transport domain', 
//url_onto: 'http://sisinflab.poliba.it/ruta/bag/iDriveSafe.txt',
//image: '../images/domainOnto/transport.png',
//},
//
//{ name_onto: 'Fuchs Transport ontology', 
//	domain_onto: 'Transport domain', 
//url_onto: 'http://vi.uni-klu.ac.at/ontology/DrivingContext.owl',
//image: '../images/domainOnto/transport.png',
//},
//
//{ name_onto: 'Bonsai ontology',
//domain_onto: 'Home domain', 
//url_onto: 'http://lpis.csd.auth.gr/ontologies/bonsai/BOnSAI.owl',
//image: '../images/domainOnto/home.png',
//},
//	      	                { name_onto: 'Kinect ontology', 
//	      	                	domain_onto: 'Activity recognition domain', 
//	                            	url_onto: 'http://users.abo.fi/rowikstr/KinectOntology/KinectOntology.owl',
//	                            	image: '../images/cloudiot/ontologies/kinect.png',
//	      	                  },
//	      	                { name_onto: 'Food tiscali ontology', 
//		      	                	domain_onto: 'Food domain', 
//		                            	url_onto: 'http://web.tiscali.it/lchkl/ontology/FoodOntology.owl#',
//		                            	image: '../images/domainOnto/food.png',
//		      	                  },
//	      	                    
//	      	                  
//	                          ];

//function visualizeOntoWithWebvowl_dropdownlist(){
//	
//	 var webvowl = "http://vowl.visualdataweb.org/webvowl/#iri="
//		
//	//javascript change iframe source
//	document.getElementById('webvowl').src = webvowl + document.getElementById('list_ontologies').value;	
//}
//
//function visualizeOntoWithWebvowl_imageslist(self, url_onto){
//	//alert(url_onto);// always sao why
//	 var webvowl = "http://vowl.visualdataweb.org/webvowl/#iri="
//	//javascript change iframe source
//	document.getElementById('webvowl_pictures').src = webvowl + self.alt;//url_onto	
//	 
//	 
//}
//
//
//function display_onto_picture(){
//	var par = document.getElementById('imageDiv');
//	var url = "";
//	for(i = 0; i < list_onto_to_visualize.length; i++)	{
//		var img = document.createElement('img');
//		img.src = list_onto_to_visualize[i].image;
//		img.width = "100";
//		img.height = "100";
//		img.title = list_onto_to_visualize[i].name_onto + " - " + list_onto_to_visualize[i].domain_onto;
//		img.alt = list_onto_to_visualize[i].url_onto;
//		img.style.backgroundImage = list_onto_to_visualize[i].image;
//		img.id = "imageSelected" + i;
//		
//		//var self = this;
//		url = list_onto_to_visualize[i].url_onto;
//		//alert(url);
//		// add on click call
//		// var webvowl = "http://vowl.visualdataweb.org/webvowl/#iri="	
//		//javascript change iframe source
//		
//		//alert(document.getElementById('imageSelected').value);
//		//img.onclick = "visualizeOntoWithWebvowl_imageslist("+list_onto_to_visualize[i].url_onto+")";
//		//img.onclick = function(url) { visualizeOntoWithWebvowl_imageslist(url);};
//		img.addEventListener("click", function(){
//			visualizeOntoWithWebvowl_imageslist(this, url);
//		});
//		
//		//BUG: by default SAO ontology why
//		par.appendChild(img);
//
//		// img.src = list_onto_to_visualize[i].image; // img[i] refers to the current URL.
//		 //   par.appendChild(img);
//
//		
//	}
//}


//function checkSyntacticValidation(){
//	
//	//ontology selected
//	var ontology_selected = document.getElementById('list_ontologies');
//	var ontology_selected_url = ontology_selected.value;
//	//var ontology_selected_name = ontology_selected.title;
//	alert("Ontology URL selected: " + ontology_selected_url);
//	
//	
//	//use owl validator mowl-power.cs.man.ac.uk:8080/validator/
//}
//
//function checkVisualizationValidation(){
//	var ontology_selected = document.getElementById('list_ontologies');
//	var ontology_selected_url = ontology_selected.value;
//	//alert("Ontology URL selected: " + ontology_selected_url);
//	
//	var webvowl = "http://vowl.visualdataweb.org/webvowl/#iri=";
//
//
//var table = document.getElementById('ontology_table');
////add a clickable link for visualiwation of ok
//var a = document.createElement('a');
//var linkText = document.createTextNode("Ontology working with WebOWL");
//a.appendChild(linkText);
//a.title = ontology_selected_url;
//a.href = webvowl + ontology_selected_url;
//document.body.appendChild(a);
//
//row = table.insertRow(0);
//var cell11 = row.insertCell(0);
////var cell12 = row.insertCell(1);
////var cell13 = row.insertCell(2);
////var cell14 = row.insertCell(3);
////cell11.innerHTML = testbedLabel  + "&nbsp;&nbsp;&nbsp;";
////cell12.innerHTML = sensor  + "&nbsp;&nbsp;&nbsp;";
////cell13.innerHTML = domain + "&nbsp;&nbsp;&nbsp;";
//cell11.appendChild(a);// data endpoint URL link
//
////execute Web VOWL if ok display it display the link webvowl+ link
////if error show errord
////}
//	
//	//use owl validator mowl-power.cs.man.ac.uk:8080/validator/
//}
//
//function populateListOntologies (){
//	
//	//TODO add pictures for each ontology
//	
//	var ul = document.getElementById('list_ontologies'), li;
//	
//	// var webvowl = "http://vowl.visualdataweb.org/webvowl/#iri="
//	
//	//fill the list
//	// document.getElementById('list_ontologies').value = myselect.value;
//	for(i = 0; i < list_onto_to_visualize.length; i++)	{
//		li = document.createElement('option');
//		li.setAttribute('title', list_onto_to_visualize[i].name_onto);
//		li.setAttribute('value', list_onto_to_visualize[i].url_onto );
//		//+ list_onto_to_visualize[i].image
//		li.appendChild(document.createTextNode(list_onto_to_visualize[i].name_onto));//"name onto // parse list onto list_onto_to_visualize
//		ul.appendChild(li);
//		
//		//javascript change iframe source
//		//document.getElementById('webvowl').src = webvowl + list_onto_to_visualize[i].url_onto;
//	}
//}
//
//
//
//function suggest_new_tool_to_perfecto(result_email){
//	var paper = document.getElementById('paper').value;
//	var url_tool = document.getElementById('url_tool').value;
//	var url_code = document.getElementById('url_code').value;
//	var url_web_service = document.getElementById('url_web_service').value;
//	var authors = document.getElementById('authors').value;
//	
//
//	var data = "paper=" + paper;
//	data += "&url_tool=" + url_tool;
//	data += "&url_code=" + url_code;
//	data += "&url_web_service=" + url_web_service;
//	data += "&authors=" + authors;
//	
//	request(afficherText, '/perfecto/suggestNewTool/?' + data, 'suggest_new_tool');
//	
//	alert("/perfecto/suggestNewTool/?" + data +" Thank you. The message has been sent!");
//	
//}