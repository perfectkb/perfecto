PerfectO Web site:

http://purl.org/perfecto
which redirects to:  http://perfectsemanticweb.appspot.com


 https://github.com/perfectkb